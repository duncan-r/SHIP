ship.utils.fileloaders package
==============================

Submodules
----------

ship.utils.fileloaders.datloader module
---------------------------------------

.. automodule:: ship.utils.fileloaders.datloader
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.fileloaders.fileloader module
----------------------------------------

.. automodule:: ship.utils.fileloaders.fileloader
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.fileloaders.iefloader module
---------------------------------------

.. automodule:: ship.utils.fileloaders.iefloader
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.fileloaders.loader module
------------------------------------

.. automodule:: ship.utils.fileloaders.loader
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.fileloaders.tuflowloader module
------------------------------------------

.. automodule:: ship.utils.fileloaders.tuflowloader
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ship.utils.fileloaders
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread package
==========================

Submodules
----------

ship.utils.dbfread.codepages module
-----------------------------------

.. automodule:: ship.utils.dbfread.codepages
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.dbf module
-----------------------------

.. automodule:: ship.utils.dbfread.dbf
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.dbversions module
------------------------------------

.. automodule:: ship.utils.dbfread.dbversions
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.deprecated_dbf module
----------------------------------------

.. automodule:: ship.utils.dbfread.deprecated_dbf
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.exceptions module
------------------------------------

.. automodule:: ship.utils.dbfread.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.field_parser module
--------------------------------------

.. automodule:: ship.utils.dbfread.field_parser
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.ifiles module
--------------------------------

.. automodule:: ship.utils.dbfread.ifiles
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.memo module
------------------------------

.. automodule:: ship.utils.dbfread.memo
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.struct_parser module
---------------------------------------

.. automodule:: ship.utils.dbfread.struct_parser
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.test_field_parser module
-------------------------------------------

.. automodule:: ship.utils.dbfread.test_field_parser
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.test_ifiles module
-------------------------------------

.. automodule:: ship.utils.dbfread.test_ifiles
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.test_invalid_value module
--------------------------------------------

.. automodule:: ship.utils.dbfread.test_invalid_value
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.test_memo module
-----------------------------------

.. automodule:: ship.utils.dbfread.test_memo
    :members:
    :undoc-members:
    :show-inheritance:

ship.utils.dbfread.test_read_and_length module
----------------------------------------------

.. automodule:: ship.utils.dbfread.test_read_and_length
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ship.utils.dbfread
    :members:
    :undoc-members:
    :show-inheritance:
